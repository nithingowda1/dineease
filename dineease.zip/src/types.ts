export type TabType = 'home' | 'search' | 'orders' | 'reserve';

export type DiningArea = 'main' | 'terrace' | 'private';

export interface AddonOption {
  id: string;
  name: string;
  price: number;
}

export interface Dish {
  id: string;
  name: string;
  category: 'Starters' | 'Mains' | 'Pizza' | 'Desserts' | 'Beverages';
  price: number;
  description: string;
  longDescription: string;
  image: string;
  isVeg: boolean;
  rating: number;
  reviewsCount: string;
  cuisine: string;
  spiceOptions?: ('Mild' | 'Medium' | 'Hot')[];
  defaultSpice?: 'Mild' | 'Medium' | 'Hot';
  addons?: AddonOption[];
  pairsWellWith?: string[]; // IDs of complementary dishes
  calories?: number;
  isChefSpecial?: boolean;
}

export interface CartItem {
  id: string; // unique item instance ID in cart
  dishId: string;
  dish: Dish;
  quantity: number;
  selectedSpice?: 'Mild' | 'Medium' | 'Hot';
  selectedAddons: AddonOption[];
  unitPrice: number;
  totalPrice: number;
  specialNotes?: string;
}

export interface Reservation {
  id: string;
  area: DiningArea;
  date: string;
  time: string;
  guests: number;
  fullName: string;
  phone: string;
  email: string;
  specialRequests?: string;
  status: 'Confirmed' | 'Completed' | 'Cancelled';
  createdAt: string;
}

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  tip: number;
  total: number;
  orderType: 'Dine-In' | 'Takeaway' | 'Delivery';
  tableNumber?: string;
  deliveryAddress?: string;
  status: 'Order Placed' | 'In the Kitchen' | 'Ready to Serve' | 'Completed';
  createdAt: string;
  estimatedMinutes: number;
}
