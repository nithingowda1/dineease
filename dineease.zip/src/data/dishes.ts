import { Dish } from '../types';

export const HERO_BACKGROUND_IMAGE = 'https://lh3.googleusercontent.com/aida-public/AB6AXuA8CbsiSDBySeqa463OiaE7m2VlfjPoGs5hhBJP1t4x0k8qZteKAj3XqmZnu071WfQZIunJOvEJ6laDQJawiKzYM9jhEL51_q_5F61b8s-5RXoK2hP7EwCn4Aiay8zNa4adwV94tOQFg7-nBNUdIAE5YItU9PtL8sb51GYBPQQjdDHP7_SMhG_8AYI21OxfoA-LK0Zi04nonthW_vy85FZFNkRNazb_61bRi5B0zDXYQf_sEtah0ukY';

export const RESERVATION_HERO_IMAGE = 'https://lh3.googleusercontent.com/aida-public/AB6AXuBNYckbfcec-stSguj4NEgMabjt_mPeA1EzbBk7U8bvLvQSWgL3HjXgfjQhh07UbV5Dsn-nCJOOKDmHqwd-GGFdhnHv6RfBOnNIq5zktw9WoiO9ZgqUM4yZgsd3fb2_0JhasJf-iCA44isUQzlyzmzZUHez_zd-fWmGYw-4pVifjriPNRHY7I2dgfgJN72Hdg54zr91GYwC0NelgHQxboQJt2Ksj4R2yqeSnpr8-RHn4dSMxJxAi_wW';

export const DISHES: Dish[] = [
  {
    id: 'caprese-salad',
    name: 'Caprese Salad',
    category: 'Starters',
    price: 12.00,
    description: 'Fresh mozzarella, tomatoes, sweet basil, balsamic glaze.',
    longDescription: 'Imported artisanal Buffalo mozzarella layered with vine-ripened heirloom tomatoes, wild sweet basil, cold-pressed Tuscan olive oil, and aged Modena balsamic reduction. An authentic celebration of Italian minimalism.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDNXjPX4OZLkZJwgbvk2LR2TQfy5cYh7Aa_EAHTNaE68tkZZ_TUBhSbJSS-vdoprrNekZtwB9j5qmNdeHvd04dAlmf-jHJO1Jooeg3VffD6lbWsQ_PPb1-qKh4YAIDZ9CkjNy7u3bc5b7RFVONGWO20ydoMbsYJZUmdM6unLRBHnk75VEdcyHo3Ah1eaY7whQRawZKNAF-F5nioq1Vye-2XJS4DBGmLGwV1M1wErVImgxn0gte8AFM7',
    isVeg: true,
    rating: 4.8,
    reviewsCount: '840 reviews',
    cuisine: 'Italian Antipasto',
    spiceOptions: ['Mild'],
    defaultSpice: 'Mild',
    addons: [
      { id: 'extra-mozzarella', name: 'Extra Buffalo Mozzarella', price: 3.50 },
      { id: 'focaccia-bread', name: 'Toasted Garlic Focaccia', price: 3.00 }
    ],
    pairsWellWith: ['jeera-rice', 'mango-lassi'],
    calories: 340,
    isChefSpecial: false
  },
  {
    id: 'crispy-calamari',
    name: 'Crispy Calamari',
    category: 'Starters',
    price: 14.50,
    description: 'Lightly breaded squid rings served with garlic aioli.',
    longDescription: 'Tender Monterey Bay squid dusted in seasoned sea-salt flour, crisped to a golden crunch. Served with roasted garlic citrus aioli, house-smoked paprika dip, and grilled Meyer lemon wedges.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDupvpZHWhWgAgojHBvY1gSW_O8PxHBvr3Ydh7FIEciW73hZNwDFnZjxkNwEljzqHGN5pgzzh6L6g2ZQXW4Zm-v6uGy3frQVaipUV-jGgR0FLXVEJHeEULUnY4hT-DK0-2Rb7k0njr1rA23jk7SMIxPUMtupsqm3joY4uN2hclE79CK4bEvs_g5U-s9f4NYNdXIy9WSO25hfps-vSURpcUXsJdlytJQ3wq606dghY_7DT5-zPRCD1oC',
    isVeg: false,
    rating: 4.6,
    reviewsCount: '620 reviews',
    cuisine: 'Mediterranean',
    spiceOptions: ['Mild', 'Medium'],
    defaultSpice: 'Mild',
    addons: [
      { id: 'extra-aioli', name: 'Truffle Garlic Aioli', price: 2.00 },
      { id: 'spicy-marinara', name: 'Charred Arrabiata Sauce', price: 2.00 }
    ],
    pairsWellWith: ['mango-lassi', 'truffle-mushroom-risotto'],
    calories: 420,
    isChefSpecial: true
  },
  {
    id: 'butter-chicken',
    name: 'Signature Butter Chicken',
    category: 'Mains',
    price: 24.00,
    description: 'Tender chicken tikka simmered in rich aromatic tomato fenugreek gravy.',
    longDescription: 'Our award-winning adaptation of a beloved classic. Tender, overnight-marinated chicken tikka simmered in a velvet-smooth, aromatic tomato and fenugreek gravy. Finished with farm-fresh cream and a touch of organic honey for an unforgettable balance of richness and subtle heat.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDQQg0bDriulsA4CaO0HIjkDYKUjnUTHPS6O31ndIoHV2abHe5ntg2YQU22ks3sVVLsaVrJoijEGswfZmPixSs6wM0IPLMxUmW0Izxno-jo7tADn18Q_Q-VKcsZcYWy0H2Ojnimj1mX0AL9M6ZOy1kF4ajdsmyYEVW0QMSSf3y43IwOJntyu16-wd0D1BLOrL_wt5qde54f4g2ZPDK58f5z3OFYRD7ARN2KOY_zXa3V4gzR_OsEbV6k',
    isVeg: false,
    rating: 4.9,
    reviewsCount: '1.2k reviews',
    cuisine: 'North Indian',
    spiceOptions: ['Mild', 'Medium', 'Hot'],
    defaultSpice: 'Medium',
    addons: [
      { id: 'garlic-naan', name: 'Garlic Naan', price: 4.00 },
      { id: 'extra-chicken', name: 'Extra Portion Chicken', price: 8.50 },
      { id: 'butter-roti', name: 'Clay Oven Butter Roti (2 pcs)', price: 3.50 }
    ],
    pairsWellWith: ['mango-lassi', 'jeera-rice'],
    calories: 680,
    isChefSpecial: true
  },
  {
    id: 'mango-lassi',
    name: 'Mango Lassi',
    category: 'Beverages',
    price: 6.00,
    description: 'Chilled artisanal yogurt blended with sweet Alphonso mangoes and cardamom.',
    longDescription: 'A cooling, velvety blend of golden Alphonso mango purée, slow-cultured organic yogurt, crushed green cardamom pods, and a sprinkle of Iranian saffron strands. Served with crushed ice and fresh mint.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB3TgH2yq6ImGg1a3Kstr43pojkZhsom5IYn07_lFXQfGrx4oRRI_bzjIDJwDmBbQDTDIHYkDuGifDI_ZMKTRlQSvyKSlahuec3ym-oAkURkFJfcZ3wpH5PL5K3cb9yNreHXOzAk96sQ8GJtvWj-0CY8GS-Q05Q1vf2Ky7dCJgU2_vnP3NKOU-9LBQ9afQZhINUMANOc8lgVstzi5mX3mUYHven9OP_ixpUpl1VSjv2R0pWeSj91VDv',
    isVeg: true,
    rating: 4.9,
    reviewsCount: '950 reviews',
    cuisine: 'Beverage & Elixir',
    spiceOptions: ['Mild'],
    defaultSpice: 'Mild',
    addons: [
      { id: 'pistachio-crush', name: 'Roasted Pistachio Crunch', price: 1.00 },
      { id: 'chia-seeds', name: 'Hydrated Chia Seeds', price: 0.75 }
    ],
    pairsWellWith: ['butter-chicken', 'caprese-salad'],
    calories: 220,
    isChefSpecial: false
  },
  {
    id: 'jeera-rice',
    name: 'Jeera Rice',
    category: 'Mains',
    price: 5.00,
    description: 'Fragrant aged basmati rice tempered with roasted cumin and ghee.',
    longDescription: 'Aromatic Himalayan royal basmati rice gently steamed and tempered in grass-fed organic ghee, whole roasted cumin seeds, cinnamon bark, and fresh garden coriander leaves.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCfe_OExH62eSIh-Ojqrivkpjdbl7F6Jl2e1ff1dRi_noo5ZFo3sEh8b0t4H6s5fVePIPebjns4v_afkTvN9VVFoJbzbpw9o5fw6NfhH9VvyMpPUOvsJszy6dQIWjsVtwZtJORTdMpyh0XAc2r78r0qO4VeS3PK5YqZPHey8iIyifSdOJJkjedo6ieFS6DmFLPe_4xGpFeWlm4PxwAwrUEltQRRC9C1V_kpDMpQWLRI1nQ36eUjt_92',
    isVeg: true,
    rating: 4.7,
    reviewsCount: '510 reviews',
    cuisine: 'North Indian',
    spiceOptions: ['Mild'],
    defaultSpice: 'Mild',
    addons: [
      { id: 'fried-onions', name: 'Caramelized Crispy Shallots', price: 1.50 }
    ],
    pairsWellWith: ['butter-chicken'],
    calories: 260,
    isChefSpecial: false
  },
  {
    id: 'margherita-pizza',
    name: 'Artisan Margherita Pizza',
    category: 'Pizza',
    price: 18.00,
    description: 'San Marzano DOP tomatoes, fresh fior di latte, basil, olive oil.',
    longDescription: 'Fermented for 48 hours for a pillowy leopard-spotted crust. Topped with hand-crushed San Marzano tomatoes, fresh fior di latte mozzarella, fresh basil, and finished with organic extra virgin olive oil.',
    image: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?auto=format&fit=crop&w=800&q=80',
    isVeg: true,
    rating: 4.8,
    reviewsCount: '1.1k reviews',
    cuisine: 'Neapolitan Wood-Fired',
    spiceOptions: ['Mild', 'Medium'],
    defaultSpice: 'Mild',
    addons: [
      { id: 'prosciutto-di-parma', name: 'Prosciutto di Parma', price: 4.50 },
      { id: 'truffle-oil-drizzle', name: 'Black Truffle Oil Drizzle', price: 3.00 },
      { id: 'extra-burrata', name: 'Whole Burrata Crown', price: 5.00 }
    ],
    pairsWellWith: ['crispy-calamari', 'mango-lassi'],
    calories: 780,
    isChefSpecial: false
  },
  {
    id: 'truffle-mushroom-risotto',
    name: 'Truffle Mushroom Risotto',
    category: 'Mains',
    price: 22.00,
    description: 'Carnaroli rice, wild forest mushrooms, 24-month Parmigiano, truffle.',
    longDescription: 'Slow-cooked Italian Carnaroli rice infused with white wine, porcini mushroom broth, sautéed wild chanterelles, 24-month aged Parmigiano-Reggiano, and finished with fresh shaved black truffles and micro herbs.',
    image: 'https://images.unsplash.com/photo-1633964913295-ceb43826e7c9?auto=format&fit=crop&w=800&q=80',
    isVeg: true,
    rating: 4.9,
    reviewsCount: '780 reviews',
    cuisine: 'Northern Italian',
    spiceOptions: ['Mild'],
    defaultSpice: 'Mild',
    addons: [
      { id: 'extra-truffle', name: 'Fresh Shaved Black Truffle', price: 6.00 },
      { id: 'pan-seared-scallop', name: 'Pan-Seared Sea Scallops (2 pcs)', price: 7.50 }
    ],
    pairsWellWith: ['caprese-salad'],
    calories: 610,
    isChefSpecial: true
  },
  {
    id: 'dark-chocolate-lava',
    name: 'Molten Chocolate Lava Cake',
    category: 'Desserts',
    price: 11.00,
    description: 'Warm Valrhona chocolate ganache center with Madagascar vanilla gelato.',
    longDescription: 'Baked to order featuring 70% single-origin Valrhona dark chocolate. A delicate cake shell holding a molten core, paired with hand-churned Madagascar bourbon vanilla bean gelato and gold leaf.',
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=80',
    isVeg: true,
    rating: 4.9,
    reviewsCount: '1.4k reviews',
    cuisine: 'French Pastry',
    spiceOptions: ['Mild'],
    defaultSpice: 'Mild',
    addons: [
      { id: 'raspberry-coulis', name: 'Fresh Raspberry Puree', price: 1.50 },
      { id: 'espresso-shot', name: 'Illy Espresso Shot', price: 2.50 }
    ],
    pairsWellWith: ['mango-lassi'],
    calories: 490,
    isChefSpecial: true
  }
];

export const INITIAL_ORDERS: import('../types').Order[] = [
  {
    id: 'DE-8924',
    items: [
      {
        id: 'cart-init-1',
        dishId: 'butter-chicken',
        dish: DISHES[2],
        quantity: 1,
        selectedSpice: 'Medium',
        selectedAddons: [{ id: 'garlic-naan', name: 'Garlic Naan', price: 4.00 }],
        unitPrice: 28.00,
        totalPrice: 28.00
      },
      {
        id: 'cart-init-2',
        dishId: 'jeera-rice',
        dish: DISHES[4],
        quantity: 1,
        selectedSpice: 'Mild',
        selectedAddons: [],
        unitPrice: 5.00,
        totalPrice: 5.00
      }
    ],
    subtotal: 33.00,
    tax: 2.97,
    tip: 5.00,
    total: 40.97,
    orderType: 'Dine-In',
    tableNumber: 'Table 14',
    status: 'In the Kitchen',
    createdAt: 'Just now',
    estimatedMinutes: 18
  }
];
