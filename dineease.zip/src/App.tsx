/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TabType, Dish, CartItem, Order, Reservation, AddonOption } from './types';
import { DISHES, INITIAL_ORDERS } from './data/dishes';
import { TopAppBar } from './components/TopAppBar';
import { BottomNavBar } from './components/BottomNavBar';
import { HomeScreen } from './components/HomeScreen';
import { MenuScreen } from './components/MenuScreen';
import { DishDetailModal } from './components/DishDetailModal';
import { ReservationScreen } from './components/ReservationScreen';
import { OrdersScreen } from './components/OrdersScreen';
import { CartDrawer } from './components/CartDrawer';
import { SideMenuDrawer } from './components/SideMenuDrawer';
import { NotificationToast } from './components/NotificationToast';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: 'cart-sample-1',
      dishId: 'caprese-salad',
      dish: DISHES[0],
      quantity: 1,
      selectedSpice: 'Mild',
      selectedAddons: [],
      unitPrice: 12.00,
      totalPrice: 12.00,
    },
    {
      id: 'cart-sample-2',
      dishId: 'crispy-calamari',
      dish: DISHES[1],
      quantity: 1,
      selectedSpice: 'Mild',
      selectedAddons: [],
      unitPrice: 14.50,
      totalPrice: 14.50,
    },
  ]);
  const [selectedDishForDetail, setSelectedDishForDetail] = useState<Dish | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isMenuDrawerOpen, setIsMenuDrawerOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [reservations, setReservations] = useState<Reservation[]>([
    {
      id: 'RES-7429',
      area: 'main',
      date: '2026-08-22',
      time: '7:00 PM',
      guests: 2,
      fullName: 'Alexander Wright',
      phone: '+1 (555) 234-8901',
      email: 'alex.wright@example.com',
      specialRequests: 'Anniversary celebration. Quiet corner table requested.',
      status: 'Confirmed',
      createdAt: 'Today',
    },
  ]);

  // Toast notification state
  const [toast, setToast] = useState<{
    isOpen: boolean;
    message: string;
    subMessage?: string;
    actionLabel?: string;
    onAction?: () => void;
  }>({
    isOpen: false,
    message: '',
  });

  const showToast = (
    message: string,
    subMessage?: string,
    actionLabel?: string,
    onAction?: () => void
  ) => {
    setToast({
      isOpen: true,
      message,
      subMessage,
      actionLabel,
      onAction,
    });
    setTimeout(() => {
      setToast((prev) => ({ ...prev, isOpen: false }));
    }, 4500);
  };

  // Total cart item count
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  // Total cart price
  const cartTotal = cartItems.reduce((acc, item) => acc + item.totalPrice, 0);

  // Quick add standard item from card or carousel
  const handleQuickAdd = (dish: Dish) => {
    setCartItems((prev) => {
      const existing = prev.find(
        (i) =>
          i.dishId === dish.id &&
          i.selectedAddons.length === 0 &&
          i.selectedSpice === (dish.defaultSpice || 'Mild')
      );

      if (existing) {
        return prev.map((item) =>
          item.id === existing.id
            ? {
                ...item,
                quantity: item.quantity + 1,
                totalPrice: (item.quantity + 1) * item.unitPrice,
              }
            : item
        );
      } else {
        const newItem: CartItem = {
          id: `cart-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          dishId: dish.id,
          dish,
          quantity: 1,
          selectedSpice: dish.defaultSpice || 'Mild',
          selectedAddons: [],
          unitPrice: dish.price,
          totalPrice: dish.price,
        };
        return [...prev, newItem];
      }
    });

    showToast(
      `Added ${dish.name} to order`,
      `$${dish.price.toFixed(2)}`,
      'View Cart',
      () => setIsCartOpen(true)
    );
  };

  // Add customized item from Detail Modal
  const handleAddToCart = (
    dish: Dish,
    quantity: number,
    spice: 'Mild' | 'Medium' | 'Hot',
    addons: AddonOption[],
    notes?: string
  ) => {
    const addonsTotal = addons.reduce((sum, a) => sum + a.price, 0);
    const unitPrice = dish.price + addonsTotal;
    const totalPrice = unitPrice * quantity;

    const newItem: CartItem = {
      id: `cart-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      dishId: dish.id,
      dish,
      quantity,
      selectedSpice: spice,
      selectedAddons: addons,
      unitPrice,
      totalPrice,
      specialNotes: notes,
    };

    setCartItems((prev) => [...prev, newItem]);
    showToast(
      `Added ${quantity}x ${dish.name}`,
      `Total: $${totalPrice.toFixed(2)}`,
      'View Cart',
      () => setIsCartOpen(true)
    );
  };

  const handleUpdateQuantity = (cartItemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveCartItem(cartItemId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.id === cartItemId
          ? {
              ...item,
              quantity: newQuantity,
              totalPrice: newQuantity * item.unitPrice,
            }
          : item
      )
    );
  };

  const handleRemoveCartItem = (cartItemId: string) => {
    setCartItems((prev) => prev.filter((i) => i.id !== cartItemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handlePlaceOrder = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
    setCurrentTab('orders');
    showToast(
      'Order Sent to Kitchen!',
      `Order #${newOrder.id} • Est. ${newOrder.estimatedMinutes} mins`,
      'Track',
      () => setCurrentTab('orders')
    );
  };

  const handleReservationComplete = (newRes: Reservation) => {
    setReservations((prev) => [newRes, ...prev]);
    showToast(
      'Table Confirmed!',
      `${newRes.time} for ${newRes.guests} Guests (${newRes.area})`,
      'View',
      () => setCurrentTab('orders')
    );
  };

  const handleReorder = (order: Order) => {
    const reorderedItems: CartItem[] = order.items.map((item) => ({
      ...item,
      id: `cart-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    }));
    setCartItems((prev) => [...prev, ...reorderedItems]);
    setIsCartOpen(true);
    showToast(`Added ${order.items.length} items from #${order.id} back to cart`);
  };

  const handleSearchSubmit = () => {
    setCurrentTab('search');
  };

  // Scroll to top on tab change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentTab]);

  return (
    <div className="min-h-screen bg-[#131313] text-[#e4e2e1] flex flex-col font-sans selection:bg-[#F4A261] selection:text-[#0e0e0e]">
      {/* Fixed Top Bar */}
      <TopAppBar
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenMenu={() => setIsMenuDrawerOpen(true)}
        onTitleClick={() => setCurrentTab('home')}
      />

      {/* Main Tab Content */}
      <main className="flex-1 pt-16">
        {currentTab === 'home' && (
          <HomeScreen
            onNavigate={(tab) => setCurrentTab(tab)}
            onSelectDish={(dish) => setSelectedDishForDetail(dish)}
            onQuickAdd={handleQuickAdd}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onSearchSubmit={handleSearchSubmit}
          />
        )}

        {currentTab === 'search' && (
          <MenuScreen
            onSelectDish={(dish) => setSelectedDishForDetail(dish)}
            onQuickAdd={handleQuickAdd}
            cartCount={cartCount}
            cartTotal={cartTotal}
            onOpenCart={() => setIsCartOpen(true)}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />
        )}

        {currentTab === 'reserve' && (
          <ReservationScreen
            onReservationComplete={handleReservationComplete}
          />
        )}

        {currentTab === 'orders' && (
          <OrdersScreen
            orders={orders}
            reservations={reservations}
            onNavigate={(tab) => setCurrentTab(tab)}
            onReorder={handleReorder}
          />
        )}
      </main>

      {/* Fixed Bottom Navigation Bar */}
      <BottomNavBar
        currentTab={currentTab}
        onTabChange={(tab) => setCurrentTab(tab)}
        activeOrdersCount={orders.length}
      />

      {/* Dish Detail Modal View */}
      {selectedDishForDetail && (
        <DishDetailModal
          dish={selectedDishForDetail}
          onClose={() => setSelectedDishForDetail(null)}
          onAddToCart={handleAddToCart}
          onQuickAddOther={handleQuickAdd}
        />
      )}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onPlaceOrder={handlePlaceOrder}
      />

      {/* Side Menu Drawer */}
      <SideMenuDrawer
        isOpen={isMenuDrawerOpen}
        onClose={() => setIsMenuDrawerOpen(false)}
        onNavigate={(tab) => setCurrentTab(tab)}
      />

      {/* Toast Notification */}
      <NotificationToast
        isOpen={toast.isOpen}
        message={toast.message}
        subMessage={toast.subMessage}
        actionLabel={toast.actionLabel}
        onAction={toast.onAction}
        onClose={() => setToast((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
}
