import React from 'react';
import { Search, Sparkles, UtensilsCrossed, Calendar, ChevronRight, Star, Clock, Award } from 'lucide-react';
import { Dish, TabType } from '../types';
import { HERO_BACKGROUND_IMAGE, DISHES } from '../data/dishes';

interface HomeScreenProps {
  onNavigate: (tab: TabType) => void;
  onSelectDish: (dish: Dish) => void;
  onQuickAdd: (dish: Dish) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSearchSubmit: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  onSelectDish,
  onQuickAdd,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
}) => {
  const chefSpecials = DISHES.filter((d) => d.isChefSpecial || d.rating >= 4.8);

  return (
    <div className="min-h-screen pb-24 md:pb-12 text-[#e4e2e1]">
      {/* Hero Section */}
      <section className="relative h-[530px] min-h-[440px] w-full flex items-center justify-center overflow-hidden md:rounded-2xl md:mt-2 shadow-2xl">
        {/* Background Photo */}
        <div
          className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 scale-105"
          style={{ backgroundImage: `url('${HERO_BACKGROUND_IMAGE}')` }}
        />
        {/* Cinematic Gradient Mask */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#131313] via-[#131313]/65 to-black/30" />

        {/* Hero Content */}
        <div className="relative z-10 px-4 text-center w-full max-w-lg mx-auto flex flex-col items-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1b1c1c]/80 border border-[#444748]/50 text-[#cdc6b8] text-xs font-semibold uppercase tracking-widest mb-4 backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#F4A261]" />
            <span>Michelin Guided Dining</span>
          </div>

          <h2 className="font-serif text-[34px] sm:text-[42px] md:text-[48px] leading-[1.15] font-bold text-white mb-6 drop-shadow-lg tracking-tight">
            Delicious Food,
            <br />
            <span className="italic font-normal text-[#cdc6b8]">Memorable Moments</span>
          </h2>

          <div className="flex flex-col sm:flex-row gap-3 w-full max-w-xs sm:max-w-md mx-auto">
            <button
              onClick={() => onNavigate('search')}
              className="bg-[#F4A261] text-[#0e0e0e] font-sans font-bold text-[14px] uppercase tracking-wider py-3.5 px-6 rounded-full w-full hover:bg-[#f6b078] transition-all shadow-lg hover:shadow-[#F4A261]/20 active:scale-95"
            >
              Order Now
            </button>
            <button
              onClick={() => onNavigate('reserve')}
              className="bg-transparent border border-[#cdc6b8] text-[#cdc6b8] hover:text-white hover:border-white font-sans font-bold text-[14px] uppercase tracking-wider py-3.5 px-6 rounded-full w-full hover:bg-[#353535]/40 transition-all active:scale-95 backdrop-blur-sm"
            >
              Book a Table
            </button>
          </div>
        </div>
      </section>

      {/* Floating Search Bar */}
      <section className="px-4 mt-[-24px] relative z-20 max-w-xl mx-auto">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            onSearchSubmit();
          }}
          className="bg-[#2a2a2a] rounded-full p-1.5 flex items-center shadow-[0_12px_32px_rgba(0,0,0,0.7)] border border-[#444748]/50 focus-within:border-[#F4A261] focus-within:ring-1 focus-within:ring-[#F4A261] transition-all"
        >
          <Search className="ml-3.5 w-5 h-5 text-[#c4c7c7] shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search for dishes, cuisines, ingredients..."
            className="bg-transparent border-none text-[#e4e2e1] font-sans text-sm md:text-base w-full focus:outline-none placeholder-[#c4c7c7]/50 px-3 py-1.5"
          />
          <button
            type="submit"
            className="bg-[#F4A261] text-[#0e0e0e] px-4 py-2 rounded-full font-sans text-xs font-bold uppercase tracking-wider hover:bg-[#f6b078] transition-colors shrink-0 mr-1"
          >
            Explore
          </button>
        </form>
      </section>

      {/* Highlights & Chef's Special */}
      <section className="mt-12 px-4 max-w-[1200px] mx-auto">
        <div className="flex items-end justify-between mb-5">
          <div>
            <div className="flex items-center gap-1.5 text-[#F4A261] text-xs font-bold uppercase tracking-widest mb-1">
              <Award className="w-4 h-4" />
              <span>Chef's Choice</span>
            </div>
            <h3 className="font-serif text-2xl md:text-3xl font-bold text-white">
              Signature Specialties
            </h3>
          </div>
          <button
            onClick={() => onNavigate('search')}
            className="text-xs text-[#cdc6b8] hover:text-[#F4A261] font-semibold flex items-center gap-1 transition-colors"
          >
            Full Menu <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Horizontal Carousel */}
        <div className="flex gap-4 overflow-x-auto pb-4 pt-1 hide-scrollbar snap-x snap-mandatory">
          {chefSpecials.map((dish) => (
            <div
              key={dish.id}
              className="snap-start shrink-0 w-[270px] sm:w-[300px] bg-[#1b1c1c] rounded-2xl overflow-hidden border border-[#353535] hover:border-[#444748] transition-all duration-300 group shadow-lg flex flex-col justify-between"
            >
              <div
                onClick={() => onSelectDish(dish)}
                className="relative h-44 w-full overflow-hidden cursor-pointer"
              >
                <img
                  src={dish.image}
                  alt={dish.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1b1c1c] via-transparent to-transparent opacity-80" />

                {/* Dietary badge */}
                <div className="absolute top-3 left-3 bg-[#131313]/80 backdrop-blur-md px-2.5 py-1 rounded-full flex items-center gap-1.5 border border-white/10">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      dish.isVeg ? 'bg-emerald-500' : 'bg-rose-500'
                    }`}
                  />
                  <span className="text-[11px] font-semibold text-[#e4e2e1]">
                    {dish.cuisine}
                  </span>
                </div>

                {/* Rating */}
                <div className="absolute top-3 right-3 bg-[#131313]/80 backdrop-blur-md px-2 py-1 rounded-full flex items-center gap-1 border border-white/10 text-[12px] font-bold text-[#F4A261]">
                  <Star className="w-3.5 h-3.5 fill-[#F4A261] text-[#F4A261]" />
                  <span>{dish.rating}</span>
                </div>
              </div>

              <div className="p-4 flex flex-col justify-between flex-1">
                <div>
                  <h4
                    onClick={() => onSelectDish(dish)}
                    className="font-serif text-lg font-bold text-white group-hover:text-[#F4A261] transition-colors line-clamp-1 cursor-pointer"
                  >
                    {dish.name}
                  </h4>
                  <p className="text-xs text-[#c4c7c7] line-clamp-2 mt-1 leading-relaxed">
                    {dish.description}
                  </p>
                </div>

                <div className="flex items-center justify-between mt-4 pt-3 border-t border-[#353535]/60">
                  <span className="font-serif text-lg font-bold text-white">
                    ${dish.price.toFixed(2)}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onSelectDish(dish)}
                      className="px-3 py-1.5 rounded-lg bg-[#2a2a2a] text-[#cdc6b8] hover:text-white text-xs font-semibold transition-colors"
                    >
                      Details
                    </button>
                    <button
                      onClick={() => onQuickAdd(dish)}
                      className="w-8 h-8 rounded-full bg-[#2f0004] text-[#e83a47] hover:bg-[#e83a47] hover:text-white flex items-center justify-center transition-all active:scale-95 font-bold shadow-sm"
                      title="Quick Add to Cart"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Fast reservation callout card */}
      <section className="mt-8 px-4 max-w-[1200px] mx-auto">
        <div className="bg-gradient-to-r from-[#1b1c1c] via-[#2a2a2a] to-[#1b1c1c] border border-[#353535] rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 bg-[#F4A261]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="space-y-2 text-center md:text-left z-10">
            <div className="inline-flex items-center gap-2 text-[#F4A261] text-xs font-bold uppercase tracking-widest">
              <Calendar className="w-4 h-4" />
              <span>Private & Terrace Dining</span>
            </div>
            <h3 className="font-serif text-2xl md:text-3xl font-bold text-white">
              Reserve Your Table in Seconds
            </h3>
            <p className="text-sm text-[#c4c7c7] max-w-md">
              Whether celebrating a milestone or enjoying an intimate evening, select your preferred ambiance in advance.
            </p>
          </div>

          <button
            onClick={() => onNavigate('reserve')}
            className="z-10 bg-[#e83a47] hover:bg-[#ff4d5d] text-white px-7 py-3.5 rounded-full font-sans text-sm font-bold uppercase tracking-wider flex items-center gap-2 transition-all shadow-lg hover:shadow-[#e83a47]/30 active:scale-95 shrink-0"
          >
            <span>Book Table</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* Quick Service Highlights */}
      <section className="mt-12 px-4 max-w-[1200px] mx-auto grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#1b1c1c]/70 border border-[#353535] rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#2f0004] text-[#e83a47] flex items-center justify-center shrink-0">
            <UtensilsCrossed className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-serif font-bold text-white text-base">Farm-Fresh Flavors</h4>
            <p className="text-xs text-[#c4c7c7]">Artisanal spices & organic produce</p>
          </div>
        </div>

        <div className="bg-[#1b1c1c]/70 border border-[#353535] rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#4d493e] text-[#F4A261] flex items-center justify-center shrink-0">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-serif font-bold text-white text-base">Express Table & Takeout</h4>
            <p className="text-xs text-[#c4c7c7]">Prepared to perfection in 20 mins</p>
          </div>
        </div>

        <div className="bg-[#1b1c1c]/70 border border-[#353535] rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#2a2a2a] text-[#cdc6b8] flex items-center justify-center shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-serif font-bold text-white text-base">Master Culinary Arts</h4>
            <p className="text-xs text-[#c4c7c7]">Curated by Executive Chef Marco</p>
          </div>
        </div>
      </section>
    </div>
  );
};
