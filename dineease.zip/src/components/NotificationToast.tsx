import React from 'react';
import { CheckCircle2, ShoppingBag, X } from 'lucide-react';

interface ToastProps {
  message: string;
  subMessage?: string;
  isOpen: boolean;
  onClose: () => void;
  onAction?: () => void;
  actionLabel?: string;
}

export const NotificationToast: React.FC<ToastProps> = ({
  message,
  subMessage,
  isOpen,
  onClose,
  onAction,
  actionLabel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed top-20 left-4 right-4 max-w-sm mx-auto z-50 animate-in slide-in-from-top-4 duration-300">
      <div className="bg-[#1f2020] border border-[#F4A261]/60 text-[#e4e2e1] rounded-2xl p-3.5 shadow-2xl flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-[#2f0004] text-[#e83a47] flex items-center justify-center shrink-0 border border-[#e83a47]/50">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-sans text-xs font-bold text-white">{message}</h4>
            {subMessage && (
              <p className="font-sans text-[11px] text-[#cdc6b8] mt-0.5">{subMessage}</p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onAction && actionLabel && (
            <button
              onClick={onAction}
              className="bg-[#F4A261] text-[#0e0e0e] text-[11px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider hover:bg-[#f6b078]"
            >
              {actionLabel}
            </button>
          )}
          <button
            onClick={onClose}
            className="text-[#c4c7c7] hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
