import React, { useState } from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  ArrowRight,
  Sparkles,
  Tag,
  Check,
  Utensils,
  ShoppingBag as BagIcon,
  Truck,
} from 'lucide-react';
import { CartItem, Order } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQuantity: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
  onPlaceOrder: (newOrder: Order) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onPlaceOrder,
}) => {
  if (!isOpen) return null;

  const [orderType, setOrderType] = useState<'Dine-In' | 'Takeaway' | 'Delivery'>('Dine-In');
  const [tableNumber, setTableNumber] = useState<string>('Table 14');
  const [deliveryAddress, setDeliveryAddress] = useState<string>('742 Evergreen Terrace, Apt 4B');
  const [promoCode, setPromoCode] = useState<string>('');
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);
  const [promoError, setPromoError] = useState<string>('');
  const [tipPercentage, setTipPercentage] = useState<number>(18);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Math Calculations
  const rawSubtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);
  const discountAmount = (rawSubtotal * appliedDiscount) / 100;
  const subtotal = Math.max(0, rawSubtotal - discountAmount);
  const tax = subtotal * 0.09; // 9% tax
  const tip = (subtotal * tipPercentage) / 100;
  const deliveryFee = orderType === 'Delivery' ? 3.99 : 0;
  const grandTotal = subtotal + tax + tip + deliveryFee;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError('');
    if (promoCode.trim().toUpperCase() === 'WELCOME10' || promoCode.trim().toUpperCase() === 'DINE10') {
      setAppliedDiscount(10);
    } else if (promoCode.trim().toUpperCase() === 'CHEF20') {
      setAppliedDiscount(20);
    } else {
      setPromoError('Invalid promo code. Try DINE10');
    }
  };

  const handleCheckout = () => {
    if (items.length === 0) return;
    setIsSubmitting(true);

    setTimeout(() => {
      const orderId = `DE-${Math.floor(1000 + Math.random() * 9000)}`;
      const newOrder: Order = {
        id: orderId,
        items: [...items],
        subtotal,
        tax,
        tip,
        total: grandTotal,
        orderType,
        tableNumber: orderType === 'Dine-In' ? tableNumber : undefined,
        deliveryAddress: orderType === 'Delivery' ? deliveryAddress : undefined,
        status: 'Order Placed',
        createdAt: 'Just now',
        estimatedMinutes: orderType === 'Dine-In' ? 18 : 28,
      };

      onPlaceOrder(newOrder);
      onClearCart();
      setIsSubmitting(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex justify-end animate-in fade-in">
      <div className="bg-[#191919] w-full max-w-md h-full flex flex-col justify-between border-l border-[#353535] shadow-2xl text-[#e4e2e1] overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-[#353535] flex items-center justify-between bg-[#1f2020]">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#F4A261]" />
            <h2 className="font-serif text-lg font-bold text-white">Your Order</h2>
            <span className="text-xs bg-[#2a2a2a] text-[#cdc6b8] px-2 py-0.5 rounded-full font-bold">
              {items.reduce((s, i) => s + i.quantity, 0)} items
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#c4c7c7] hover:text-white hover:bg-[#353535] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Items list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 hide-scrollbar">
          {items.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <ShoppingBag className="w-12 h-12 text-[#444748] mx-auto" />
              <p className="font-serif text-lg text-[#c4c7c7]">Your cart is currently empty</p>
              <p className="text-xs text-[#c4c7c7]/70">Explore our chef-curated menu to add delicious dishes.</p>
            </div>
          ) : (
            <>
              {/* Dining Option Toggle */}
              <div className="bg-[#1f2020] p-1.5 rounded-xl border border-[#353535] grid grid-cols-3 gap-1">
                {[
                  { id: 'Dine-In', label: 'Dine-In', icon: Utensils },
                  { id: 'Takeaway', label: 'Takeaway', icon: BagIcon },
                  { id: 'Delivery', label: 'Delivery', icon: Truck },
                ].map((type) => {
                  const Icon = type.icon;
                  const isSelected = orderType === type.id;
                  return (
                    <button
                      key={type.id}
                      onClick={() => setOrderType(type.id as any)}
                      className={`py-2 px-1 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                        isSelected
                          ? 'bg-[#2f0004] text-[#e83a47] border border-[#e83a47]/40 shadow-sm'
                          : 'text-[#c4c7c7] hover:text-white'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{type.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Order Location inputs */}
              {orderType === 'Dine-In' && (
                <div className="bg-[#1f2020] p-3 rounded-xl border border-[#353535] flex items-center justify-between text-xs">
                  <span className="text-[#c4c7c7]">Seating / Table:</span>
                  <input
                    type="text"
                    value={tableNumber}
                    onChange={(e) => setTableNumber(e.target.value)}
                    placeholder="e.g. Table 14"
                    className="bg-[#2a2a2a] text-white font-bold px-3 py-1 rounded-lg border border-[#444748] w-28 text-center focus:border-[#F4A261] focus:outline-none"
                  />
                </div>
              )}

              {orderType === 'Delivery' && (
                <div className="bg-[#1f2020] p-3 rounded-xl border border-[#353535] text-xs space-y-1">
                  <span className="text-[#c4c7c7] block">Delivery Destination:</span>
                  <input
                    type="text"
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    className="w-full bg-[#2a2a2a] text-white px-3 py-1.5 rounded-lg border border-[#444748] focus:border-[#F4A261] focus:outline-none"
                  />
                </div>
              )}

              {/* Items Card List */}
              <div className="space-y-3">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="bg-[#1f2020] border border-[#353535] rounded-xl p-3 flex gap-3 items-start"
                  >
                    <img
                      src={item.dish.image}
                      alt={item.dish.name}
                      className="w-16 h-16 rounded-lg object-cover shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h4 className="font-sans text-sm font-semibold text-white truncate pr-2">
                          {item.dish.name}
                        </h4>
                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-[#c4c7c7] hover:text-red-400 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Spice & Addons info */}
                      <div className="text-[11px] text-[#c4c7c7] space-y-0.5 mt-0.5">
                        {item.selectedSpice && (
                          <span className="inline-block mr-2 text-[#cdc6b8]">
                            Spice: {item.selectedSpice}
                          </span>
                        )}
                        {item.selectedAddons.length > 0 && (
                          <div className="text-[10px] text-[#cdc6b8]/80 truncate">
                            +{item.selectedAddons.map((a) => a.name).join(', ')}
                          </div>
                        )}
                        {item.specialNotes && (
                          <div className="text-[10px] text-amber-200/80 italic truncate">
                            Note: {item.specialNotes}
                          </div>
                        )}
                      </div>

                      <div className="flex justify-between items-center mt-2.5">
                        <span className="font-sans text-sm font-bold text-white">
                          ${item.totalPrice.toFixed(2)}
                        </span>

                        {/* Quantity Counter */}
                        <div className="flex items-center gap-2 bg-[#2a2a2a] rounded-lg px-2 py-0.5 border border-[#444748]">
                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                            className="text-[#c4c7c7] hover:text-white p-0.5"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-bold text-white w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                            className="text-[#c4c7c7] hover:text-white p-0.5"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Promo code input */}
              <form onSubmit={handleApplyPromo} className="space-y-1">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#c4c7c7]" />
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      placeholder="Promo code (e.g. DINE10)"
                      className="w-full bg-[#1f2020] text-xs text-white border border-[#353535] rounded-lg py-2 pl-8 pr-3 focus:border-[#F4A261] focus:outline-none uppercase"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-3 py-2 bg-[#2a2a2a] text-[#cdc6b8] hover:text-white text-xs font-semibold rounded-lg border border-[#444748] transition-colors"
                  >
                    Apply
                  </button>
                </div>
                {appliedDiscount > 0 && (
                  <p className="text-[11px] text-green-400 flex items-center gap-1">
                    <Check className="w-3 h-3" /> {appliedDiscount}% Chef courtesy discount applied!
                  </p>
                )}
                {promoError && <p className="text-[11px] text-red-400">{promoError}</p>}
              </form>

              {/* Tip Selection */}
              <div className="bg-[#1f2020] p-3 rounded-xl border border-[#353535] space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-[#c4c7c7] font-medium">Add Staff Tip</span>
                  <span className="text-xs font-bold text-white">${tip.toFixed(2)}</span>
                </div>
                <div className="grid grid-cols-4 gap-1.5">
                  {[10, 15, 18, 20].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setTipPercentage(pct)}
                      className={`py-1.5 rounded-lg text-xs font-bold transition-colors ${
                        tipPercentage === pct
                          ? 'bg-[#F4A261] text-[#0e0e0e]'
                          : 'bg-[#2a2a2a] text-[#c4c7c7] hover:text-white'
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer Summary & Place Order */}
        {items.length > 0 && (
          <div className="p-4 bg-[#1f2020] border-t border-[#353535] space-y-3">
            <div className="space-y-1.5 text-xs text-[#c4c7c7]">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="text-white">${rawSubtotal.toFixed(2)}</span>
              </div>
              {appliedDiscount > 0 && (
                <div className="flex justify-between text-green-400 font-medium">
                  <span>Discount ({appliedDiscount}%)</span>
                  <span>-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Tax (9%)</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Staff Gratuity</span>
                <span>${tip.toFixed(2)}</span>
              </div>
              {orderType === 'Delivery' && (
                <div className="flex justify-between">
                  <span>Courier Service</span>
                  <span>${deliveryFee.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-bold text-white pt-1.5 border-t border-[#353535]">
                <span>Total</span>
                <span className="text-[#F4A261]">${grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              disabled={isSubmitting}
              className="w-full bg-[#e83a47] hover:bg-[#ff4d5d] disabled:opacity-50 text-white font-sans font-bold text-sm py-3.5 rounded-xl shadow-xl flex items-center justify-center gap-2 transition-all active:scale-95 uppercase tracking-wider"
            >
              <span>{isSubmitting ? 'Sending to Kitchen...' : `Place Order • $${grandTotal.toFixed(2)}`}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
