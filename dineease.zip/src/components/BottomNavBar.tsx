import React from 'react';
import { Home, Search, Receipt, Calendar } from 'lucide-react';
import { TabType } from '../types';

interface BottomNavBarProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
  activeOrdersCount?: number;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentTab,
  onTabChange,
  activeOrdersCount = 0,
}) => {
  const tabs: { id: TabType; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'search', label: 'Search', icon: Search },
    { id: 'orders', label: 'Orders', icon: Receipt },
    { id: 'reserve', label: 'Reserve', icon: Calendar },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#1f2020]/90 backdrop-blur-xl border-t border-[#353535]/40 shadow-[0_-4px_20px_rgba(0,0,0,0.6)] flex justify-around items-center h-16 px-4 max-w-[1200px] mx-auto md:rounded-t-2xl">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentTab === tab.id;

        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`relative flex flex-col items-center justify-center transition-all duration-300 ease-out py-1 px-4 rounded-full ${
              isActive
                ? 'bg-[#2f0004] text-[#e83a47] scale-100 shadow-inner'
                : 'text-[#c4c7c7] hover:text-[#e4e2e1] hover:bg-[#353535]/30'
            }`}
          >
            <div className="relative flex items-center justify-center">
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-[1.75px]'}`} />
              {tab.id === 'orders' && activeOrdersCount > 0 && !isActive && (
                <span className="absolute -top-1 -right-2 bg-[#F4A261] text-[#0e0e0e] text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {activeOrdersCount}
                </span>
              )}
            </div>
            <span
              className={`font-sans text-[12px] font-bold tracking-wider mt-0.5 ${
                isActive ? 'text-[#e83a47]' : 'text-[#c4c7c7]'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
