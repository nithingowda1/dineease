import React, { useState } from 'react';
import {
  Utensils,
  Sun,
  DoorClosed,
  Calendar,
  Users,
  ChevronDown,
  ArrowRight,
  CheckCircle2,
  Clock,
  MapPin,
  Sparkles,
} from 'lucide-react';
import { DiningArea, Reservation } from '../types';
import { RESERVATION_HERO_IMAGE } from '../data/dishes';

interface ReservationScreenProps {
  onReservationComplete: (reservation: Reservation) => void;
}

export const ReservationScreen: React.FC<ReservationScreenProps> = ({
  onReservationComplete,
}) => {
  const [selectedArea, setSelectedArea] = useState<DiningArea>('main');
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [guestsCount, setGuestsCount] = useState<number>(2);
  const [selectedTime, setSelectedTime] = useState<string>('7:00 PM');
  const [fullName, setFullName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [specialRequests, setSpecialRequests] = useState<string>('');
  const [confirmedReservation, setConfirmedReservation] = useState<Reservation | null>(null);
  const [errors, setErrors] = useState<{ name?: string; phone?: string; email?: string }>({});

  const areas: { id: DiningArea; label: string; icon: React.FC<{ className?: string }>; desc: string }[] = [
    { id: 'main', label: 'Main Dining', icon: Utensils, desc: 'Sophisticated ambient atmosphere' },
    { id: 'terrace', label: 'Terrace', icon: Sun, desc: 'Breezy outdoor views under lanterns' },
    { id: 'private', label: 'Private Room', icon: DoorClosed, desc: 'Exclusive cellar suite & sommelier' },
  ];

  const timeSlots = [
    { time: '12:00 PM', status: 'Available', isLunch: true },
    { time: '1:00 PM', status: 'Available', isLunch: true },
    { time: '7:00 PM', status: 'Available', isLunch: false },
    { time: '7:30 PM', status: 'Available', isLunch: false },
    { time: '8:00 PM', status: 'Fast Filling', isLunch: false },
    { time: '8:30 PM', status: 'Available', isLunch: false },
    { time: '9:00 PM', status: 'Available', isLunch: false },
  ];

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { name?: string; phone?: string; email?: string } = {};

    if (!fullName.trim()) newErrors.name = 'Full name is required';
    if (!phone.trim()) newErrors.phone = 'Phone number is required';
    if (!email.trim() || !email.includes('@')) newErrors.email = 'Valid email is required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const newRes: Reservation = {
      id: `RES-${Math.floor(1000 + Math.random() * 9000)}`,
      area: selectedArea,
      date: selectedDate,
      time: selectedTime,
      guests: guestsCount,
      fullName,
      phone,
      email,
      specialRequests,
      status: 'Confirmed',
      createdAt: 'Just now',
    };

    setConfirmedReservation(newRes);
    onReservationComplete(newRes);
  };

  if (confirmedReservation) {
    return (
      <div className="min-h-screen pt-4 pb-28 max-w-lg mx-auto px-4 text-[#e4e2e1] animate-in fade-in">
        <div className="bg-[#1b1c1c] border border-[#353535] rounded-2xl p-6 sm:p-8 shadow-2xl text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-[#2f0004] text-[#e83a47] flex items-center justify-center mx-auto border-2 border-[#e83a47]">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#F4A261]">
              Reservation Confirmed
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-white mt-1">
              We Look Forward to Welcoming You
            </h2>
            <p className="text-xs text-[#c4c7c7] mt-2">
              Confirmation reference code has been sent to {confirmedReservation.email}
            </p>
          </div>

          {/* Ticket pass summary */}
          <div className="bg-[#2a2a2a] rounded-xl p-4 text-left border border-[#444748]/50 space-y-3">
            <div className="flex justify-between items-center border-b border-[#353535] pb-2">
              <span className="text-xs text-[#c4c7c7]">Reference Number</span>
              <span className="font-mono text-sm font-bold text-[#F4A261]">
                {confirmedReservation.id}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[#c4c7c7] block">Guest Name</span>
                <span className="font-semibold text-white">{confirmedReservation.fullName}</span>
              </div>
              <div>
                <span className="text-[#c4c7c7] block">Party Size</span>
                <span className="font-semibold text-white">{confirmedReservation.guests} Guests</span>
              </div>
              <div>
                <span className="text-[#c4c7c7] block">Date</span>
                <span className="font-semibold text-white">{confirmedReservation.date}</span>
              </div>
              <div>
                <span className="text-[#c4c7c7] block">Seating Time</span>
                <span className="font-semibold text-white">{confirmedReservation.time}</span>
              </div>
              <div className="col-span-2">
                <span className="text-[#c4c7c7] block">Selected Dining Area</span>
                <span className="font-semibold text-[#F4A261] capitalize">
                  {confirmedReservation.area === 'main'
                    ? 'Main Dining Hall'
                    : confirmedReservation.area === 'terrace'
                    ? 'Garden Terrace'
                    : 'Private Wine Cellar'}
                </span>
              </div>
            </div>

            {confirmedReservation.specialRequests && (
              <div className="border-t border-[#353535] pt-2 text-xs">
                <span className="text-[#c4c7c7] block">Special Notes</span>
                <p className="text-white italic">{confirmedReservation.specialRequests}</p>
              </div>
            )}
          </div>

          <div className="space-y-3">
            <button
              onClick={() => setConfirmedReservation(null)}
              className="w-full bg-[#F4A261] text-[#0e0e0e] font-sans font-bold text-sm py-3.5 rounded-full uppercase tracking-wider hover:bg-[#f6b078] transition-colors"
            >
              Book Another Table
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-4 pb-36 max-w-lg mx-auto px-4 text-[#e4e2e1]">
      {/* Header */}
      <div className="mb-4">
        <h2 className="font-serif text-2xl md:text-3xl font-bold text-white tracking-tight">
          Book a Table
        </h2>
        <p className="text-xs text-[#c4c7c7] mt-1">
          Reserve an exquisite culinary journey at DineEase
        </p>
      </div>

      {/* Hero Image Banner */}
      <div className="w-full h-48 rounded-xl mb-6 overflow-hidden relative shadow-xl border border-[#353535]">
        <img
          src={RESERVATION_HERO_IMAGE}
          alt="Luxury Restaurant Dining Room"
          className="object-cover w-full h-full"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#131313]/90 via-[#131313]/20 to-transparent" />
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5 bg-[#131313]/80 px-2.5 py-1 rounded-full border border-white/10 text-xs font-semibold text-[#cdc6b8]">
          <MapPin className="w-3.5 h-3.5 text-[#F4A261]" />
          <span>Table Allocation Confirmed on Arrival</span>
        </div>
      </div>

      <form onSubmit={handleConfirm} className="space-y-6">
        {/* Section: Area Selection */}
        <section>
          <h3 className="font-sans text-base font-semibold text-white mb-3 flex items-center justify-between">
            <span>Select Area</span>
            <span className="text-xs text-[#c4c7c7] font-normal">3 settings available</span>
          </h3>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-1">
            {areas.map((area) => {
              const Icon = area.icon;
              const isSelected = selectedArea === area.id;
              return (
                <button
                  key={area.id}
                  type="button"
                  onClick={() => setSelectedArea(area.id)}
                  className={`flex-shrink-0 w-32 h-24 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all duration-200 ${
                    isSelected
                      ? 'bg-[#2a2a2a] border-[#F4A261] ring-1 ring-[#F4A261] text-white shadow-md'
                      : 'bg-[#1b1c1c] border-[#444748]/50 text-[#c4c7c7] hover:border-[#8e9192] hover:text-white'
                  }`}
                >
                  <Icon
                    className={`w-6 h-6 ${
                      isSelected ? 'text-[#F4A261]' : 'text-[#c4c7c7]'
                    }`}
                  />
                  <span className="font-sans text-xs font-semibold">{area.label}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Section: Date & Guests */}
        <section className="bg-[#1b1c1c] rounded-xl p-4 border border-[#353535] shadow-md">
          <div className="grid grid-cols-2 gap-3">
            {/* Date */}
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-[#c4c7c7] mb-1.5">
                Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#c4c7c7] pointer-events-none" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full bg-[#2a2a2a] text-[#e4e2e1] text-xs font-semibold rounded-lg border border-[#444748] py-2.5 pl-9 pr-2 focus:border-[#F4A261] focus:ring-1 focus:ring-[#F4A261] focus:outline-none"
                />
              </div>
            </div>

            {/* Guests */}
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-[#c4c7c7] mb-1.5">
                Guests
              </label>
              <div className="relative">
                <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#c4c7c7] pointer-events-none" />
                <select
                  value={guestsCount}
                  onChange={(e) => setGuestsCount(Number(e.target.value))}
                  className="w-full bg-[#2a2a2a] text-[#e4e2e1] text-xs font-semibold rounded-lg border border-[#444748] py-2.5 pl-9 pr-7 focus:border-[#F4A261] focus:ring-1 focus:ring-[#F4A261] focus:outline-none appearance-none cursor-pointer"
                >
                  <option value={1}>1 Person</option>
                  <option value={2}>2 People</option>
                  <option value={3}>3 People</option>
                  <option value={4}>4 People</option>
                  <option value={5}>5 People</option>
                  <option value={6}>6 People</option>
                  <option value={7}>7 People</option>
                  <option value={8}>8 People</option>
                  <option value={9}>9 People</option>
                  <option value={10}>10 People (VIP)</option>
                </select>
                <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#c4c7c7] pointer-events-none" />
              </div>
            </div>
          </div>
        </section>

        {/* Section: Time Slots */}
        <section>
          <div className="flex justify-between items-end mb-3">
            <h3 className="font-sans text-base font-semibold text-white">
              Select Time
            </h3>
            <span className="text-xs text-[#cdc6b8] font-medium">
              Dinner Service (Prime)
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {timeSlots.map((slot) => {
              const isSelected = selectedTime === slot.time;
              const isFastFilling = slot.status === 'Fast Filling';

              return (
                <button
                  key={slot.time}
                  type="button"
                  onClick={() => setSelectedTime(slot.time)}
                  className={`py-3 px-2 rounded-xl border flex flex-col items-center justify-center transition-all ${
                    isSelected
                      ? 'bg-[#2f0004] border-[#e83a47] text-[#e83a47] ring-1 ring-[#e83a47] shadow-md'
                      : 'bg-[#1b1c1c] border-[#444748]/50 text-[#e4e2e1] hover:bg-[#2a2a2a]'
                  }`}
                >
                  <span className="font-sans text-sm font-bold">{slot.time}</span>
                  <span
                    className={`text-[10px] mt-0.5 font-semibold ${
                      isSelected
                        ? 'text-[#e83a47]'
                        : isFastFilling
                        ? 'text-[#ffb4ab]'
                        : 'text-[#cdc6b8]'
                    }`}
                  >
                    {isSelected ? 'Selected' : slot.status}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Section: Guest Details */}
        <section className="bg-[#1b1c1c] rounded-xl p-4 border border-[#353535] shadow-md space-y-3">
          <h3 className="font-sans text-base font-semibold text-white mb-1">
            Guest Details
          </h3>

          <div>
            <input
              type="text"
              value={fullName}
              onChange={(e) => {
                setFullName(e.target.value);
                if (errors.name) setErrors({ ...errors, name: undefined });
              }}
              placeholder="Full Name"
              className={`w-full bg-[#2a2a2a] text-[#e4e2e1] text-sm rounded-lg border ${
                errors.name ? 'border-red-500' : 'border-[#444748]'
              } py-2.5 px-3.5 focus:border-[#F4A261] focus:outline-none placeholder-[#c4c7c7]/60`}
            />
            {errors.name && <p className="text-[11px] text-red-400 mt-1">{errors.name}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <input
                type="tel"
                value={phone}
                onChange={(e) => {
                  setPhone(e.target.value);
                  if (errors.phone) setErrors({ ...errors, phone: undefined });
                }}
                placeholder="Phone Number"
                className={`w-full bg-[#2a2a2a] text-[#e4e2e1] text-sm rounded-lg border ${
                  errors.phone ? 'border-red-500' : 'border-[#444748]'
                } py-2.5 px-3.5 focus:border-[#F4A261] focus:outline-none placeholder-[#c4c7c7]/60`}
              />
              {errors.phone && <p className="text-[11px] text-red-400 mt-1">{errors.phone}</p>}
            </div>

            <div>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) setErrors({ ...errors, email: undefined });
                }}
                placeholder="Email Address"
                className={`w-full bg-[#2a2a2a] text-[#e4e2e1] text-sm rounded-lg border ${
                  errors.email ? 'border-red-500' : 'border-[#444748]'
                } py-2.5 px-3.5 focus:border-[#F4A261] focus:outline-none placeholder-[#c4c7c7]/60`}
              />
              {errors.email && <p className="text-[11px] text-red-400 mt-1">{errors.email}</p>}
            </div>
          </div>

          <div>
            <textarea
              rows={2}
              value={specialRequests}
              onChange={(e) => setSpecialRequests(e.target.value)}
              placeholder="Special Requests (Allergies, Occasion, Seating preference, etc.)"
              className="w-full bg-[#2a2a2a] text-[#e4e2e1] text-sm rounded-lg border border-[#444748] py-2 px-3.5 focus:border-[#F4A261] focus:outline-none placeholder-[#c4c7c7]/60 resize-none"
            />
          </div>
        </section>

        {/* Sticky Confirm Reservation Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full bg-[#e83a47] hover:bg-[#ff4d5d] text-white font-sans font-bold text-sm sm:text-base py-4 rounded-xl shadow-xl transition-all flex items-center justify-center gap-2 active:scale-95 uppercase tracking-wider"
          >
            <span>Confirm Reservation</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </form>
    </div>
  );
};
