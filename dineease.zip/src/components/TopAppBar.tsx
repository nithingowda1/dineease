import React from 'react';
import { Menu, ShoppingBag } from 'lucide-react';

interface TopAppBarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenMenu: () => void;
  onTitleClick?: () => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({
  cartCount,
  onOpenCart,
  onOpenMenu,
  onTitleClick,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#131313]/85 backdrop-blur-xl border-b border-white/5 transition-all duration-300">
      <div className="max-w-[1200px] mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
        {/* Menu Button */}
        <button
          onClick={onOpenMenu}
          aria-label="Open Navigation Menu"
          className="text-[#c4c7c7] hover:text-[#e4e2e1] p-2 rounded-full hover:bg-white/5 transition-colors active:scale-95 flex items-center justify-center"
        >
          <Menu className="w-6 h-6" />
        </button>

        {/* Brand Title */}
        <button
          onClick={onTitleClick}
          className="text-center focus:outline-none group"
        >
          <h1 className="font-serif text-[26px] md:text-[32px] font-bold text-[#c8c6c5] tracking-tight group-hover:text-white transition-colors">
            DineEase
          </h1>
        </button>

        {/* Shopping Cart Button with Dynamic Badge */}
        <button
          onClick={onOpenCart}
          aria-label="View Shopping Cart"
          className="relative text-[#c4c7c7] hover:text-[#e4e2e1] p-2 rounded-full hover:bg-white/5 transition-colors active:scale-95 flex items-center justify-center"
        >
          <ShoppingBag className="w-6 h-6" />
          {cartCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 bg-[#E63946] text-white text-[11px] font-bold min-w-[20px] h-[20px] rounded-full flex items-center justify-center px-1 border-2 border-[#131313] animate-pulse">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
};
