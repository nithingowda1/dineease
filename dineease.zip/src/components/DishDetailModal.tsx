import React, { useState } from 'react';
import { ArrowLeft, Heart, Star, Minus, Plus, Check } from 'lucide-react';
import { Dish, AddonOption } from '../types';
import { DISHES } from '../data/dishes';

interface DishDetailModalProps {
  dish: Dish | null;
  onClose: () => void;
  onAddToCart: (
    dish: Dish,
    quantity: number,
    spice: 'Mild' | 'Medium' | 'Hot',
    addons: AddonOption[],
    notes?: string
  ) => void;
  onQuickAddOther: (otherDish: Dish) => void;
}

export const DishDetailModal: React.FC<DishDetailModalProps> = ({
  dish,
  onClose,
  onAddToCart,
  onQuickAddOther,
}) => {
  if (!dish) return null;

  const [quantity, setQuantity] = useState<number>(1);
  const [selectedSpice, setSelectedSpice] = useState<'Mild' | 'Medium' | 'Hot'>(
    dish.defaultSpice || (dish.spiceOptions && dish.spiceOptions[0]) || 'Mild'
  );
  const [selectedAddons, setSelectedAddons] = useState<AddonOption[]>([]);
  const [isFavorite, setIsFavorite] = useState<boolean>(false);
  const [specialNotes, setSpecialNotes] = useState<string>('');

  const toggleAddon = (addon: AddonOption) => {
    if (selectedAddons.some((a) => a.id === addon.id)) {
      setSelectedAddons(selectedAddons.filter((a) => a.id !== addon.id));
    } else {
      setSelectedAddons([...selectedAddons, addon]);
    }
  };

  // Calculate unit price and total price
  const addonsTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
  const unitPrice = dish.price + addonsTotal;
  const totalPrice = unitPrice * quantity;

  // Find paired dishes
  const pairedDishes = (dish.pairsWellWith || [])
    .map((id) => DISHES.find((d) => d.id === id))
    .filter(Boolean) as Dish[];

  return (
    <div className="fixed inset-0 z-50 bg-[#131313] overflow-y-auto antialiased text-[#e4e2e1] animate-in fade-in duration-200">
      {/* Top Floating App Bar */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-[#131313]/80 to-transparent backdrop-blur-sm p-4">
        <div className="max-w-[1200px] mx-auto flex items-center justify-between">
          <button
            onClick={onClose}
            aria-label="Go Back"
            className="p-2.5 rounded-full bg-[#2a2a2a]/80 text-[#e4e2e1] hover:text-white hover:bg-[#353535] backdrop-blur-md transition-all active:scale-95 shadow-md"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => setIsFavorite(!isFavorite)}
            aria-label="Save to Favorites"
            className={`p-2.5 rounded-full backdrop-blur-md transition-all active:scale-95 shadow-md ${
              isFavorite
                ? 'bg-[#2f0004] text-[#e83a47] border border-[#e83a47]'
                : 'bg-[#2a2a2a]/80 text-[#e4e2e1] hover:text-white hover:bg-[#353535]'
            }`}
          >
            <Heart className={`w-5 h-5 ${isFavorite ? 'fill-[#e83a47]' : ''}`} />
          </button>
        </div>
      </header>

      <main className="pb-36 max-w-[700px] mx-auto">
        {/* Hero Image Section */}
        <div className="relative w-full h-[380px] sm:h-[440px] overflow-hidden">
          <img
            src={dish.image}
            alt={dish.name}
            className="w-full h-full object-cover"
          />
          {/* Gradient Overlay for smooth transition */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#131313] via-[#131313]/25 to-transparent" />
        </div>

        {/* Content Details */}
        <div className="relative z-10 px-4 sm:px-6 -mt-10">
          {/* Dish Title & Meta */}
          <div className="mb-8">
            <div className="flex items-start justify-between gap-4 mb-2">
              <h1 className="font-serif text-[28px] sm:text-[34px] leading-tight font-bold text-[#e4e2e1]">
                {dish.name}
              </h1>
              {/* Veg / Non-veg square badge with internal dot/square matching screenshot */}
              <div
                className={`mt-2 shrink-0 flex items-center justify-center w-6 h-6 rounded border p-0.5 ${
                  dish.isVeg ? 'border-green-600' : 'border-red-600'
                }`}
                title={dish.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
              >
                <div
                  className={`w-3.5 h-3.5 rounded-full ${
                    dish.isVeg ? 'bg-green-500' : 'bg-red-500'
                  }`}
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-[#c4c7c7]">
              <div className="flex items-center text-[#c8c6c5] font-semibold">
                <Star className="w-4 h-4 fill-[#F4A261] text-[#F4A261] mr-1" />
                <span className="text-white font-bold">{dish.rating}</span>
                <span className="ml-1 text-[#c4c7c7]">({dish.reviewsCount})</span>
              </div>
              <span className="w-1 h-1 rounded-full bg-[#444748]" />
              <span className="text-[#cdc6b8] font-medium">{dish.cuisine}</span>
              {dish.calories && (
                <>
                  <span className="w-1 h-1 rounded-full bg-[#444748]" />
                  <span className="text-[#c4c7c7]">{dish.calories} kcal</span>
                </>
              )}
            </div>
          </div>

          {/* Description ("The Experience") */}
          <div className="mb-8 bg-[#1b1c1c] border border-[#353535]/60 rounded-2xl p-4 sm:p-5">
            <h2 className="font-serif text-lg font-bold text-white mb-2">
              The Experience
            </h2>
            <p className="font-sans text-sm text-[#c4c7c7] leading-relaxed">
              {dish.longDescription}
            </p>
          </div>

          {/* Spice Level Selector */}
          {dish.spiceOptions && dish.spiceOptions.length > 1 && (
            <div className="mb-8">
              <h2 className="font-serif text-lg font-bold text-white mb-3">
                Spice Level
              </h2>
              <div className="grid grid-cols-3 gap-3">
                {dish.spiceOptions.map((level) => {
                  const isSelected = selectedSpice === level;
                  return (
                    <button
                      key={level}
                      onClick={() => setSelectedSpice(level)}
                      className={`py-3 px-4 rounded-xl border text-center transition-all duration-200 text-sm font-semibold ${
                        isSelected
                          ? 'border-[#c8c6c5] bg-[#2a2a2a] text-white shadow-md ring-1 ring-[#c8c6c5]'
                          : 'border-[#444748] bg-[#1b1c1c] text-[#c4c7c7] hover:border-[#8e9192] hover:text-white'
                      }`}
                    >
                      {level}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Enhance Your Meal (Addons) */}
          {dish.addons && dish.addons.length > 0 && (
            <div className="mb-8">
              <h2 className="font-serif text-lg font-bold text-white mb-3">
                Enhance Your Meal
              </h2>
              <div className="space-y-2.5">
                {dish.addons.map((addon) => {
                  const isChecked = selectedAddons.some((a) => a.id === addon.id);
                  return (
                    <label
                      key={addon.id}
                      onClick={() => toggleAddon(addon)}
                      className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${
                        isChecked
                          ? 'bg-[#2a2a2a] border-[#c8c6c5] text-white'
                          : 'bg-[#1b1c1c] border-[#353535] text-[#c4c7c7] hover:bg-[#222323]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                            isChecked
                              ? 'bg-[#F4A261] border-[#F4A261] text-[#0e0e0e]'
                              : 'border-[#8e9192] bg-transparent'
                          }`}
                        >
                          {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                        <span className="font-sans text-sm sm:text-base font-medium text-[#e4e2e1]">
                          {addon.name}
                        </span>
                      </div>
                      <span className="font-sans text-sm sm:text-base text-[#cdc6b8] font-semibold">
                        +${addon.price.toFixed(2)}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          {/* Pairs Well With Section */}
          {pairedDishes.length > 0 && (
            <div className="mb-8">
              <h2 className="font-serif text-lg font-bold text-white mb-3">
                Pairs Well With
              </h2>
              <div className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar snap-x snap-mandatory">
                {pairedDishes.map((pair) => (
                  <div
                    key={pair.id}
                    className="snap-start shrink-0 w-[200px] rounded-xl bg-[#1f2020] border border-[#353535] overflow-hidden shadow-md flex flex-col justify-between"
                  >
                    <div className="h-[120px] w-full overflow-hidden">
                      <img
                        src={pair.image}
                        alt={pair.name}
                        className="w-full h-full object-cover hover:scale-105 transition-transform"
                      />
                    </div>
                    <div className="p-3">
                      <h3 className="font-sans text-sm font-semibold text-[#e4e2e1] line-clamp-1 mb-1">
                        {pair.name}
                      </h3>
                      <p className="text-xs text-[#cdc6b8] font-bold mb-2">
                        +${pair.price.toFixed(2)}
                      </p>
                      <button
                        onClick={() => onQuickAddOther(pair)}
                        className="w-full py-1.5 rounded-lg border border-[#444748] hover:border-[#F4A261] hover:text-[#F4A261] text-[#c4c7c7] text-xs font-semibold transition-colors"
                      >
                        Add to Order
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Kitchen notes */}
          <div className="mb-6">
            <label className="text-xs font-bold uppercase tracking-wider text-[#c4c7c7] block mb-2">
              Special Instructions
            </label>
            <input
              type="text"
              value={specialNotes}
              onChange={(e) => setSpecialNotes(e.target.value)}
              placeholder="e.g. Extra sauce on side, no onions..."
              className="w-full bg-[#1b1c1c] text-[#e4e2e1] text-xs rounded-xl border border-[#353535] py-2.5 px-3.5 focus:border-[#F4A261] focus:outline-none placeholder-[#c4c7c7]/50"
            />
          </div>
        </div>
      </main>

      {/* Bottom Action Bar (Fixed at bottom matching Image 5) */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#2a2a2a]/95 backdrop-blur-xl border-t border-[#353535] p-4 z-50">
        <div className="max-w-[700px] mx-auto flex items-center justify-between gap-4">
          {/* Quantity Selector */}
          <div className="flex items-center gap-3 bg-[#1f2020] rounded-full px-4 py-2 border border-[#444748]">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              disabled={quantity <= 1}
              className="text-[#c4c7c7] hover:text-white disabled:opacity-30 p-1"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="font-sans text-base font-bold text-white w-6 text-center">
              {quantity}
            </span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="text-[#c4c7c7] hover:text-white p-1"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Add to Order Button */}
          <button
            onClick={() => {
              onAddToCart(dish, quantity, selectedSpice, selectedAddons, specialNotes);
              onClose();
            }}
            className="flex-1 bg-[#c8c6c5] hover:bg-[#e5e2e1] text-[#313030] py-3.5 px-6 rounded-full font-sans font-bold text-sm sm:text-base flex items-center justify-between transition-all shadow-xl active:scale-95"
          >
            <span>Add to Order</span>
            <span className="font-bold">${totalPrice.toFixed(2)}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
