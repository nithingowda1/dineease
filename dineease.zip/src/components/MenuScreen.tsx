import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, Star, Plus, Check, ChevronRight, Sparkles } from 'lucide-react';
import { Dish } from '../types';
import { DISHES } from '../data/dishes';

interface MenuScreenProps {
  onSelectDish: (dish: Dish) => void;
  onQuickAdd: (dish: Dish) => void;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const CATEGORIES = ['All', 'Starters', 'Mains', 'Pizza', 'Desserts', 'Beverages'] as const;

export const MenuScreen: React.FC<MenuScreenProps> = ({
  onSelectDish,
  onQuickAdd,
  cartCount,
  cartTotal,
  onOpenCart,
  searchQuery,
  onSearchChange,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [dietaryFilter, setDietaryFilter] = useState<'all' | 'veg' | 'non-veg'>('all');
  const [sortBy, setSortBy] = useState<'popular' | 'price-low' | 'price-high' | 'rating'>('popular');
  const [isFilterModalOpen, setIsFilterModalOpen] = useState<boolean>(false);

  // Filtered and Sorted Dishes
  const filteredDishes = useMemo(() => {
    return DISHES.filter((dish) => {
      // Category filter
      if (selectedCategory !== 'All' && dish.category !== selectedCategory) {
        return false;
      }
      // Dietary filter
      if (dietaryFilter === 'veg' && !dish.isVeg) return false;
      if (dietaryFilter === 'non-veg' && dish.isVeg) return false;
      // Search query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchesName = dish.name.toLowerCase().includes(q);
        const matchesDesc = dish.description.toLowerCase().includes(q);
        const matchesCuisine = dish.cuisine.toLowerCase().includes(q);
        const matchesCategory = dish.category.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesCuisine && !matchesCategory) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // Default popularity
    });
  }, [selectedCategory, dietaryFilter, searchQuery, sortBy]);

  // Group by category if "All" is selected
  const groupedCategories = useMemo(() => {
    if (selectedCategory !== 'All') {
      return [{ category: selectedCategory, items: filteredDishes }];
    }
    const categoriesInOrder: (typeof CATEGORIES)[number][] = [
      'Starters',
      'Mains',
      'Pizza',
      'Desserts',
      'Beverages',
    ];
    return categoriesInOrder
      .map((cat) => ({
        category: cat,
        items: filteredDishes.filter((d) => d.category === cat),
      }))
      .filter((group) => group.items.length > 0);
  }, [selectedCategory, filteredDishes]);

  return (
    <div className="min-h-screen pt-4 pb-36 max-w-[1200px] mx-auto px-4 text-[#e4e2e1]">
      {/* Search & Filter Header */}
      <div className="mt-2 mb-4 flex gap-2 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#c4c7c7]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search menu..."
            className="w-full bg-[#2a2a2a] border border-[#444748]/40 rounded-full py-2.5 pl-10 pr-4 text-sm text-[#e4e2e1] focus:border-[#F4A261] focus:ring-1 focus:ring-[#F4A261] transition-all outline-none placeholder-[#c4c7c7]/50"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-[#c4c7c7] hover:text-white bg-[#1b1c1c] w-5 h-5 rounded-full flex items-center justify-center"
            >
              ✕
            </button>
          )}
        </div>

        <button
          onClick={() => setIsFilterModalOpen(true)}
          className={`w-10 h-10 rounded-full border border-[#444748]/50 flex items-center justify-center transition-all ${
            dietaryFilter !== 'all' || sortBy !== 'popular'
              ? 'bg-[#2f0004] text-[#e83a47] border-[#e83a47]'
              : 'bg-[#2a2a2a] text-[#c4c7c7] hover:text-white'
          }`}
          title="Filter & Sort"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>
      </div>

      {/* Category Chips Carousel */}
      <div className="flex overflow-x-auto gap-2 pb-2 hide-scrollbar mb-6 sticky top-16 z-30 bg-[#131313]/90 backdrop-blur-md pt-2">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all duration-200 ${
                isSelected
                  ? 'bg-[#2f0004] text-[#e83a47] border border-[#e83a47]/50 shadow-sm'
                  : 'bg-[#2a2a2a] text-[#c4c7c7] hover:bg-[#353535] hover:text-white border border-transparent'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Dietary filter tags if active */}
      {dietaryFilter !== 'all' && (
        <div className="flex items-center gap-2 mb-4">
          <span className="text-xs text-[#c4c7c7]">Filtered by:</span>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#1b1c1c] border border-[#353535] text-xs text-[#cdc6b8]">
            <span
              className={`w-2 h-2 rounded-full ${
                dietaryFilter === 'veg' ? 'bg-green-500' : 'bg-red-500'
              }`}
            />
            {dietaryFilter === 'veg' ? 'Vegetarian Only' : 'Non-Vegetarian'}
            <button
              onClick={() => setDietaryFilter('all')}
              className="text-[#c4c7c7] hover:text-white ml-1"
            >
              ✕
            </button>
          </span>
        </div>
      )}

      {/* Menu List */}
      {groupedCategories.length === 0 ? (
        <div className="text-center py-16 px-4 bg-[#1b1c1c] rounded-2xl border border-[#353535]">
          <Sparkles className="w-10 h-10 text-[#c4c7c7] mx-auto mb-3" />
          <h3 className="font-serif text-xl font-bold text-white mb-1">No Dishes Found</h3>
          <p className="text-xs text-[#c4c7c7] max-w-sm mx-auto mb-4">
            We couldn't find any dishes matching "{searchQuery}". Try clearing search or filters.
          </p>
          <button
            onClick={() => {
              onSearchChange('');
              setSelectedCategory('All');
              setDietaryFilter('all');
            }}
            className="px-4 py-2 bg-[#F4A261] text-[#0e0e0e] text-xs font-bold uppercase rounded-full tracking-wider hover:bg-[#f6b078]"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          {groupedCategories.map((group) => (
            <section key={group.category} className="space-y-3">
              <h2 className="font-serif text-xl md:text-2xl font-bold text-white tracking-tight border-b border-[#353535] pb-2">
                {group.category}
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {group.items.map((dish) => (
                  <article
                    key={dish.id}
                    className="bg-[#1b1c1c] rounded-xl overflow-hidden border border-[#444748]/30 flex shadow-sm hover:border-[#444748] transition-all group"
                  >
                    {/* Image */}
                    <div
                      onClick={() => onSelectDish(dish)}
                      className="w-1/3 min-w-[110px] max-w-[140px] relative cursor-pointer overflow-hidden"
                    >
                      <img
                        src={dish.image}
                        alt={dish.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>

                    {/* Content */}
                    <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between">
                      <div onClick={() => onSelectDish(dish)} className="cursor-pointer">
                        <div className="flex justify-between items-start mb-1 gap-2">
                          <h3 className="font-sans text-[15px] sm:text-base text-[#e4e2e1] font-semibold line-clamp-1 group-hover:text-[#F4A261] transition-colors">
                            {dish.name}
                          </h3>
                          {/* Veg/Non-Veg symbol badge */}
                          <div
                            aria-label={dish.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
                            title={dish.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
                            className={`w-3 h-3 rounded-full flex-shrink-0 mt-1 ${
                              dish.isVeg
                                ? 'bg-green-500 border border-green-700'
                                : 'bg-red-500 border border-red-700'
                            }`}
                          />
                        </div>

                        <p className="text-xs text-[#c4c7c7] line-clamp-2 mb-2 leading-relaxed">
                          {dish.description}
                        </p>

                        <div className="flex items-center gap-1 text-[#c4c7c7] text-[12px]">
                          <Star className="w-3.5 h-3.5 fill-[#F4A261] text-[#F4A261]" />
                          <span className="font-semibold text-white">{dish.rating}</span>
                          <span className="text-[11px] text-[#c4c7c7]/70 ml-1">
                            • {dish.cuisine}
                          </span>
                        </div>
                      </div>

                      <div className="flex justify-between items-center mt-3 pt-2 border-t border-[#353535]/50">
                        <span className="font-sans text-[16px] sm:text-lg text-white font-bold">
                          ${dish.price.toFixed(2)}
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onSelectDish(dish)}
                            className="text-xs text-[#cdc6b8] hover:text-white font-medium px-2.5 py-1 rounded bg-[#2a2a2a] hover:bg-[#353535] transition-colors"
                          >
                            Customize
                          </button>
                          <button
                            onClick={() => onQuickAdd(dish)}
                            className="w-8 h-8 rounded-full bg-[#2f0004] text-[#e83a47] hover:bg-[#e83a47] hover:text-white flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-sm"
                            title="Add to cart"
                          >
                            <Plus className="w-4 h-4 stroke-[2.5]" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      {/* Mini Floating Cart Bar (Matching Image 3 precisely) */}
      {cartCount > 0 && (
        <div className="fixed bottom-[74px] left-4 right-4 max-w-[500px] mx-auto z-40">
          <button
            onClick={onOpenCart}
            className="w-full bg-[#c8c6c5] text-[#313030] rounded-xl p-3.5 shadow-[0_10px_25px_rgba(0,0,0,0.8)] flex justify-between items-center hover:bg-[#e5e2e1] active:scale-[0.98] transition-all"
          >
            <div className="flex items-center gap-2.5">
              <div className="bg-[#313030]/20 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-[#313030]">
                {cartCount}
              </div>
              <span className="font-sans text-[15px] font-bold text-[#313030]">
                View Cart
              </span>
            </div>
            <div className="flex items-center gap-1.5 font-sans font-bold text-[16px] text-[#313030]">
              <span>${cartTotal.toFixed(2)}</span>
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>
        </div>
      )}

      {/* Filter & Sort Dialog */}
      {isFilterModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end md:items-center justify-center p-0 md:p-4 animate-in fade-in">
          <div className="bg-[#1f2020] border border-[#353535] rounded-t-2xl md:rounded-2xl w-full max-w-md p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#353535] pb-3">
              <h3 className="font-serif text-xl font-bold text-white">Filter & Sort Dishes</h3>
              <button
                onClick={() => setIsFilterModalOpen(false)}
                className="text-[#c4c7c7] hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            {/* Dietary Preference */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#c4c7c7] block mb-2">
                Dietary Preference
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'all', label: 'All Items' },
                  { id: 'veg', label: 'Vegetarian' },
                  { id: 'non-veg', label: 'Non-Veg' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setDietaryFilter(item.id as any)}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all ${
                      dietaryFilter === item.id
                        ? 'bg-[#2f0004] border-[#e83a47] text-[#e83a47]'
                        : 'bg-[#2a2a2a] border-[#353535] text-[#c4c7c7] hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sort Preference */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-[#c4c7c7] block mb-2">
                Sort By
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'popular', label: 'Most Popular' },
                  { id: 'rating', label: 'Top Rated (★)' },
                  { id: 'price-low', label: 'Price: Low to High' },
                  { id: 'price-high', label: 'Price: High to Low' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setSortBy(item.id as any)}
                    className={`py-2.5 px-3 rounded-lg text-xs font-semibold border text-left transition-all flex items-center justify-between ${
                      sortBy === item.id
                        ? 'bg-[#2f0004] border-[#e83a47] text-[#e83a47]'
                        : 'bg-[#2a2a2a] border-[#353535] text-[#c4c7c7] hover:text-white'
                    }`}
                  >
                    <span>{item.label}</span>
                    {sortBy === item.id && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 flex gap-3">
              <button
                onClick={() => {
                  setDietaryFilter('all');
                  setSortBy('popular');
                }}
                className="flex-1 py-3 rounded-xl bg-[#2a2a2a] text-[#c4c7c7] hover:text-white text-xs font-bold uppercase tracking-wider transition-colors"
              >
                Reset
              </button>
              <button
                onClick={() => setIsFilterModalOpen(false)}
                className="flex-1 py-3 rounded-xl bg-[#F4A261] text-[#0e0e0e] text-xs font-bold uppercase tracking-wider hover:bg-[#f6b078] transition-colors"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
