import React, { useState } from 'react';
import {
  Receipt,
  Clock,
  CheckCircle2,
  ChefHat,
  Bell,
  UtensilsCrossed,
  RotateCcw,
  Calendar,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { Order, Reservation, TabType } from '../types';

interface OrdersScreenProps {
  orders: Order[];
  reservations: Reservation[];
  onNavigate: (tab: TabType) => void;
  onReorder: (order: Order) => void;
}

export const OrdersScreen: React.FC<OrdersScreenProps> = ({
  orders,
  reservations,
  onNavigate,
  onReorder,
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'reservations'>('orders');
  const [calledWaiterForOrder, setCalledWaiterForOrder] = useState<string | null>(null);

  const handleCallWaiter = (orderId: string) => {
    setCalledWaiterForOrder(orderId);
    setTimeout(() => {
      setCalledWaiterForOrder(null);
    }, 4000);
  };

  const getStatusStep = (status: Order['status']) => {
    switch (status) {
      case 'Order Placed':
        return 1;
      case 'In the Kitchen':
        return 2;
      case 'Ready to Serve':
        return 3;
      case 'Completed':
        return 4;
      default:
        return 1;
    }
  };

  return (
    <div className="min-h-screen pt-4 pb-36 max-w-2xl mx-auto px-4 text-[#e4e2e1]">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="font-serif text-2xl md:text-3xl font-bold text-white tracking-tight">
            Orders & Bookings
          </h2>
          <p className="text-xs text-[#c4c7c7] mt-0.5">
            Track your kitchen status and table reservations
          </p>
        </div>
      </div>

      {/* Switcher Tab */}
      <div className="bg-[#1f2020] p-1 rounded-xl border border-[#353535] grid grid-cols-2 gap-1 mb-6">
        <button
          onClick={() => setActiveTab('orders')}
          className={`py-2 px-4 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'orders'
              ? 'bg-[#2f0004] text-[#e83a47] border border-[#e83a47]/40 shadow-sm'
              : 'text-[#c4c7c7] hover:text-white'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Food Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('reservations')}
          className={`py-2 px-4 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'reservations'
              ? 'bg-[#2f0004] text-[#e83a47] border border-[#e83a47]/40 shadow-sm'
              : 'text-[#c4c7c7] hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Reservations ({reservations.length})</span>
        </button>
      </div>

      {activeTab === 'orders' ? (
        <div className="space-y-6">
          {orders.length === 0 ? (
            <div className="text-center py-16 bg-[#1b1c1c] border border-[#353535] rounded-2xl p-6 space-y-4">
              <UtensilsCrossed className="w-12 h-12 text-[#444748] mx-auto" />
              <h3 className="font-serif text-lg font-bold text-white">No Active Orders</h3>
              <p className="text-xs text-[#c4c7c7] max-w-xs mx-auto">
                Ready to taste perfection? Browse our menu and place your first order.
              </p>
              <button
                onClick={() => onNavigate('search')}
                className="bg-[#F4A261] text-[#0e0e0e] font-sans font-bold text-xs uppercase tracking-wider py-3 px-6 rounded-full hover:bg-[#f6b078]"
              >
                Browse Menu
              </button>
            </div>
          ) : (
            orders.map((order) => {
              const currentStep = getStatusStep(order.status);
              const isCalling = calledWaiterForOrder === order.id;

              return (
                <div
                  key={order.id}
                  className="bg-[#1b1c1c] border border-[#353535] rounded-2xl p-5 shadow-xl space-y-4"
                >
                  {/* Order Header */}
                  <div className="flex justify-between items-start border-b border-[#353535] pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-bold text-[#F4A261]">
                          #{order.id}
                        </span>
                        <span className="text-[11px] bg-[#2a2a2a] text-[#cdc6b8] px-2 py-0.5 rounded-full font-semibold">
                          {order.orderType} {order.tableNumber ? `• ${order.tableNumber}` : ''}
                        </span>
                      </div>
                      <span className="text-[11px] text-[#c4c7c7] mt-1 block">
                        Ordered {order.createdAt}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="font-serif text-lg font-bold text-white block">
                        ${order.total.toFixed(2)}
                      </span>
                      <span className="text-[11px] text-[#e83a47] font-bold uppercase tracking-wider">
                        {order.status}
                      </span>
                    </div>
                  </div>

                  {/* Visual Status Stepper */}
                  <div className="bg-[#2a2a2a]/60 rounded-xl p-4 border border-[#353535]">
                    <div className="flex items-center justify-between text-xs font-semibold mb-3">
                      <span className="text-[#cdc6b8] flex items-center gap-1.5">
                        <ChefHat className="w-4 h-4 text-[#F4A261]" />
                        <span>Kitchen Live Progress</span>
                      </span>
                      <span className="text-[#F4A261] flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        <span>~{order.estimatedMinutes} mins est.</span>
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-1 relative">
                      {[
                        { step: 1, label: 'Placed' },
                        { step: 2, label: 'In Kitchen' },
                        { step: 3, label: 'Plating' },
                        { step: 4, label: 'Served' },
                      ].map((s) => (
                        <div key={s.step} className="flex flex-col items-center">
                          <div
                            className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                              currentStep >= s.step
                                ? 'bg-[#e83a47] text-white shadow-md'
                                : 'bg-[#1b1c1c] text-[#c4c7c7] border border-[#444748]'
                            }`}
                          >
                            {currentStep > s.step ? (
                              <CheckCircle2 className="w-4 h-4" />
                            ) : (
                              s.step
                            )}
                          </div>
                          <span
                            className={`text-[10px] mt-1 text-center font-medium ${
                              currentStep >= s.step ? 'text-white' : 'text-[#c4c7c7]/60'
                            }`}
                          >
                            {s.label}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Items Ordered List */}
                  <div className="space-y-2 text-xs">
                    {order.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex justify-between items-center bg-[#242525] p-2 rounded-lg"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-[#F4A261] bg-[#1b1c1c] w-5 h-5 rounded flex items-center justify-center">
                            {item.quantity}x
                          </span>
                          <div>
                            <span className="font-semibold text-white">{item.dish.name}</span>
                            {item.selectedSpice && (
                              <span className="text-[#c4c7c7] text-[10px] ml-1.5">
                                ({item.selectedSpice})
                              </span>
                            )}
                          </div>
                        </div>
                        <span className="font-mono text-[#cdc6b8]">
                          ${item.totalPrice.toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => handleCallWaiter(order.id)}
                      className={`flex-1 py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                        isCalling
                          ? 'bg-green-950 border-green-600 text-green-300'
                          : 'bg-[#2a2a2a] border-[#444748] text-[#e4e2e1] hover:text-white'
                      }`}
                    >
                      <Bell className="w-3.5 h-3.5 text-[#F4A261]" />
                      <span>{isCalling ? 'Waiter Notified!' : 'Call Waiter / Table Help'}</span>
                    </button>

                    <button
                      onClick={() => onReorder(order)}
                      className="py-2.5 px-4 rounded-xl bg-[#2f0004] text-[#e83a47] hover:bg-[#e83a47] hover:text-white border border-[#e83a47]/40 text-xs font-bold transition-all flex items-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reorder</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        /* Reservations Tab */
        <div className="space-y-4">
          {reservations.length === 0 ? (
            <div className="text-center py-16 bg-[#1b1c1c] border border-[#353535] rounded-2xl p-6 space-y-4">
              <Calendar className="w-12 h-12 text-[#444748] mx-auto" />
              <h3 className="font-serif text-lg font-bold text-white">No Reservations Found</h3>
              <p className="text-xs text-[#c4c7c7] max-w-xs mx-auto">
                Secure your table in the main dining hall, private cellar, or candlelit terrace.
              </p>
              <button
                onClick={() => onNavigate('reserve')}
                className="bg-[#e83a47] text-white font-sans font-bold text-xs uppercase tracking-wider py-3 px-6 rounded-full hover:bg-[#ff4d5d]"
              >
                Book a Table
              </button>
            </div>
          ) : (
            reservations.map((res) => (
              <div
                key={res.id}
                className="bg-[#1b1c1c] border border-[#353535] rounded-2xl p-5 shadow-xl space-y-3"
              >
                <div className="flex justify-between items-start border-b border-[#353535] pb-3">
                  <div>
                    <span className="font-mono text-sm font-bold text-[#F4A261]">{res.id}</span>
                    <h3 className="font-serif text-base font-bold text-white mt-0.5">
                      {res.fullName}
                    </h3>
                  </div>
                  <span className="text-[11px] bg-[#2f0004] text-[#e83a47] border border-[#e83a47]/40 px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">
                    {res.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  <div className="bg-[#242525] p-2.5 rounded-lg">
                    <span className="text-[#c4c7c7] text-[10px] block">Date</span>
                    <span className="font-bold text-white">{res.date}</span>
                  </div>
                  <div className="bg-[#242525] p-2.5 rounded-lg">
                    <span className="text-[#c4c7c7] text-[10px] block">Time</span>
                    <span className="font-bold text-white">{res.time}</span>
                  </div>
                  <div className="bg-[#242525] p-2.5 rounded-lg col-span-2 sm:col-span-1">
                    <span className="text-[#c4c7c7] text-[10px] block">Area & Party</span>
                    <span className="font-bold text-[#cdc6b8] capitalize">
                      {res.area} ({res.guests} Guests)
                    </span>
                  </div>
                </div>

                {res.specialRequests && (
                  <p className="text-xs text-[#c4c7c7] italic bg-[#242525] p-2 rounded-lg">
                    "{res.specialRequests}"
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
