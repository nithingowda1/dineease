import React from 'react';
import {
  X,
  Sparkles,
  MapPin,
  Clock,
  Phone,
  Mail,
  Award,
  UtensilsCrossed,
  Calendar,
  Receipt,
  Heart,
  ChevronRight,
} from 'lucide-react';
import { TabType } from '../types';

interface SideMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: TabType) => void;
}

export const SideMenuDrawer: React.FC<SideMenuDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex justify-start animate-in fade-in">
      <div className="bg-[#191919] w-full max-w-xs sm:max-w-sm h-full flex flex-col justify-between border-r border-[#353535] shadow-2xl text-[#e4e2e1] overflow-y-auto hide-scrollbar">
        {/* Header */}
        <div className="p-6 border-b border-[#353535] bg-[#1f2020] flex items-center justify-between">
          <div>
            <span className="font-serif text-2xl font-bold text-white tracking-tight">
              DineEase
            </span>
            <p className="text-xs text-[#cdc6b8]">Epicurean Modern Dining</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-[#c4c7c7] hover:text-white hover:bg-[#353535] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation links */}
        <div className="p-4 space-y-1">
          {[
            { id: 'home', label: 'Home Page', icon: Sparkles },
            { id: 'search', label: 'Culinary Menu', icon: UtensilsCrossed },
            { id: 'reserve', label: 'Book a Table', icon: Calendar },
            { id: 'orders', label: 'My Orders & Bookings', icon: Receipt },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id as TabType);
                  onClose();
                }}
                className="w-full py-3 px-4 rounded-xl flex items-center justify-between text-sm font-semibold text-[#e4e2e1] hover:bg-[#2a2a2a] hover:text-white transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4 text-[#F4A261]" />
                  <span>{item.label}</span>
                </div>
                <ChevronRight className="w-4 h-4 text-[#c4c7c7]" />
              </button>
            );
          })}
        </div>

        {/* Restaurant details */}
        <div className="p-5 mx-4 my-2 bg-[#1f2020] rounded-2xl border border-[#353535] space-y-3 text-xs">
          <div className="flex items-center gap-2 text-[#F4A261] font-bold uppercase tracking-wider text-[10px]">
            <Award className="w-4 h-4" />
            <span>Michelin Star Rated 2026</span>
          </div>

          <div className="space-y-2 text-[#c4c7c7]">
            <div className="flex items-start gap-2">
              <Clock className="w-4 h-4 text-[#cdc6b8] shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-white block">Dinner Service:</span>
                <span>Tue - Sun: 5:30 PM - 11:00 PM</span>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-[#cdc6b8] shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-white block">Location:</span>
                <span>450 Grand Culinary Ave, Suite 100</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#cdc6b8] shrink-0" />
              <span>(555) 892-3463</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-[#353535] bg-[#141414] text-center text-xs text-[#c4c7c7]">
          <p>© 2026 DineEase Epicurean Group.</p>
          <p className="text-[11px] text-[#8e9192] mt-0.5">Crafted with passion for fine dining.</p>
        </div>
      </div>
    </div>
  );
};
